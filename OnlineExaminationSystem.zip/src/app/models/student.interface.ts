export interface UserInfo {
  code: string;
  name: string;
  email: string;
  phoneNo?: string | null;
}
