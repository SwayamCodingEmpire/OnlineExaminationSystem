export interface SectionPayload {
  topicCode: string;
  duration: number;
  totalMarks: number;
}
