import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgApexchartsModule } from 'ng-apexcharts';
import { StudentDashboardDTO, LeaderboardEntryDTO } from '../../../models/studentdashboard';
import { StudentDashboardService } from '../../../services/student/student-dashboard.service';

interface StudentInfo {
  name: string;
  email: string;
  code: string;
  age?: number;
  country?: string;
  state?: string;
  city?: string;
  totalExamsTaken: number;
  averageScore: number;
  rank: number;
  totalStudents: number;
}

interface LeaderboardEntry {
  name: string;
  score: number;
  time: number;
  rank?: number;
}

interface UpcomingExam {
  name: string;
  date: string;
  duration: number;
  totalMarks: number;
  topic: string;
}

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule,
    NgApexchartsModule,
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class StudentDashboardComponent implements OnInit {
  dashboardData?: StudentDashboardDTO;
  statCards: any[] = [];
  scoreTrendOptions: any = null;
  timeTrendOptions: any = null;
  topicBarChartOptions: any = null;
  difficultyPieOptions: any = null;
  attemptsTopicChart: any = null;
  examTableData: any[] = [];
  selectedLeaderboard: LeaderboardEntry[] = [];
  selectedExamName = '';
  leaderboardTimeChart: any = null;
  loading = false;
  error: string | null = null;

  get studentInfo(): StudentInfo {
    const empty: StudentInfo = {
      name: '',
      email: '',
      code: '',
      age: undefined,
      country: '',
      state: '',
      city: '',
      totalExamsTaken: 0,
      averageScore: 0,
      rank: 0,
      totalStudents: 0,
    };
    if (!this.dashboardData?.studentInfo) return empty;
    const attemptedExams = this.dashboardData.attemptedExams ?? [];
    const averageScore =
      attemptedExams.length > 0
        ? +(attemptedExams.reduce((acc, ex) => acc + ex.score, 0) / attemptedExams.length).toFixed(2)
        : 0;
    const info = this.dashboardData.studentInfo as any;
    return {
      name: info.name ?? '',
      email: info.email ?? '',
      code: info.code ?? '',
      age: info.age,
      country: info.country ?? '',
      state: info.state ?? '',
      city: info.city ?? '',
      totalExamsTaken: attemptedExams.length,
      averageScore,
      rank: this.dashboardData.classRank ?? 0,
      totalStudents: this.dashboardData.totalStudents ?? 0,
    };
  }

  get upcomingExams(): UpcomingExam[] {
    return (this.dashboardData?.upcomingExams ?? []) as UpcomingExam[];
  }

  constructor(private dashboardService: StudentDashboardService) { }

  ngOnInit(): void {
    this.loading = true;
    this.scoreTrendOptions = null;
    this.timeTrendOptions = null;
    this.topicBarChartOptions = null;
    this.difficultyPieOptions = null;
    this.attemptsTopicChart = null;
    this.leaderboardTimeChart = null;

    this.dashboardService.getDashboard().subscribe({
      next: (data) => {
        console.log(data)
        this.dashboardData = data;
        this.setStatCards();
        this.setCharts();
        this.setExamTableData();
        const mostRecent = this.getMostRecentExam();
        if (mostRecent) {
          this.selectExamForLeaderboard(
            mostRecent.examCode,
            mostRecent.examName,
            mostRecent.score,
            mostRecent.timeTaken
          );
        } else {
          this.selectedLeaderboard = [];
          this.selectedExamName = '';
          this.leaderboardTimeChart = null;
        }
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load dashboard data';
        this.loading = false;
        this.scoreTrendOptions = null;
        this.timeTrendOptions = null;
        this.topicBarChartOptions = null;
        this.difficultyPieOptions = null;
        this.attemptsTopicChart = null;
        this.leaderboardTimeChart = null;
      }
    });
  }

  // --- Topic Pagination State ---
  topicPage = 0;
  topicsPerPage = 8; // Number of topics to show per page (change as needed)

  get topicStatsCount(): number {
    return this.dashboardData?.topicStats?.length ?? 0;
  }
  get totalTopicPages(): number {
    return Math.ceil(this.topicStatsCount / this.topicsPerPage) || 1;
  }

  prevTopicPage() {
    if (this.topicPage > 0) {
      this.topicPage--;
      this.setCharts();
    }
  }
  nextTopicPage() {
    if (this.topicPage < this.totalTopicPages - 1) {
      this.topicPage++;
      this.setCharts();
    }
  }


  setStatCards() {
    const info = this.studentInfo;
    this.statCards = [
      { icon: 'fa-trophy', title: 'Overall Average', value: `${info.averageScore}%`, subtitle: 'All exams', color: 'text-primary' },
      { icon: 'fa-book-open', title: 'Exams Attempted', value: info.totalExamsTaken, subtitle: 'Total', color: 'text-success' },
      { icon: 'fa-award', title: 'Class Rank', value: `#${info.rank}`, subtitle: `Out of ${info.totalStudents}`, color: 'text-info' },
      { icon: 'fa-clock', title: 'Avg Exam Time', value: this.getAvgTime(), subtitle: 'Per exam', color: 'text-warning' }
    ];
  }

  setCharts() {
    if (!this.dashboardData) return;

    const exams = this.dashboardData.attemptedExams || [];
    const topicStats = this.dashboardData.topicStats || [];
    const difficultyStats = this.dashboardData.difficultyStats || [];
    const attemptsByTopic = this.dashboardData.topicStats?.map(ts => ({
      topic: ts.topic,
      attempts: 1 // or 0, or any default value
    })) ?? [];

    this.scoreTrendOptions = exams.length ? {
      series: [{ name: "Score", data: exams.map(d => d.score) }],
      chart: { type: 'line' as const, height: 230, toolbar: { show: false } },
      xaxis: { categories: exams.map(d => d.examName) },
      colors: ["#3B82F6"],
      stroke: { curve: 'smooth' as const, width: 3 }
    } : null;

    this.timeTrendOptions = exams.length ? {
      series: [{ name: "Time (min)", data: exams.map(d => +(d.timeTaken / 60).toFixed(1)) }],
      chart: { type: 'line' as const, height: 230, toolbar: { show: false } },
      xaxis: { categories: exams.map(d => d.examName) },
      colors: ["#F59E0B"],
      stroke: { curve: 'smooth' as const, width: 3 }
    } : null;

    this.topicBarChartOptions = topicStats.length ? {
      series: [{ name: 'Average Score', data: topicStats.map(d => d.averageScore) }],
      chart: { type: 'line' as const, height: 230, toolbar: { show: false } },
      xaxis: { categories: topicStats.map(d => d.topic) },
      colors: ['#10B981'],
      stroke: { curve: 'smooth', width: 3 },
      markers: { size: 4 }
    } : null;


    this.difficultyPieOptions = difficultyStats.length ? {
      series: difficultyStats.map(d => d.average),
      labels: difficultyStats.map(d => d.difficulty),
      chart: { type: 'donut' as const, height: 250 },
      colors: ['#3B82F6', '#F59E0B', '#EF4444'],
      legend: { position: 'bottom' as const }
    } : null;

    this.attemptsTopicChart = attemptsByTopic.length ? {
      series: [{ name: 'Attempts', data: attemptsByTopic.map(a => a.attempts) }],
      chart: { type: 'bar' as const, height: 230, toolbar: { show: false } },
      xaxis: { categories: attemptsByTopic.map(a => a.topic) },
      colors: ['#6366F1'],
    } : null;
  }

  setExamTableData() {
    if (!this.dashboardData) return;
    this.examTableData = (this.dashboardData.attemptedExams || []).map(exam => ({
      name: exam.examName,
      date: exam.date,
      topic: exam.topic,
      score: exam.score,
      time: exam.timeTaken,
      rank: exam.rank,
      difficultyBreakdown: [
        { type: 'Easy', value: exam.difficultyBreakdown?.easy ?? 0, color: 'bg-success' },
        { type: 'Medium', value: exam.difficultyBreakdown?.medium ?? 0, color: 'bg-warning' },
        { type: 'Hard', value: exam.difficultyBreakdown?.hard ?? 0, color: 'bg-danger' }
      ]
    }));
  }

  getStatColorClass(index: number): string {
    const colors = ['purple', 'blue', 'green', 'orange'];
    return colors[index % colors.length];
  }

  getRankBadgeClass(rank: number): string {
    if (rank === 1) return 'gold';
    if (rank === 2) return 'silver';
    if (rank === 3) return 'bronze';
    return '';
  }

  selectExamForLeaderboard(
    examOrCode: any,
    examName?: string,
    examScore?: number,
    examTime?: number
  ) {
    let examCode: string;
    let name: string;
    let score: number;
    let time: number;

    if (typeof examOrCode === 'object' && examOrCode !== null) {
      examCode = examOrCode.examCode || examOrCode.code || examOrCode.name || '';
      name = examOrCode.examName || examOrCode.name || '';
      score = examOrCode.score ?? 0;
      time = examOrCode.timeTaken ?? examOrCode.time ?? 0;
    } else {
      examCode = examOrCode;
      name = examName ?? '';
      score = examScore ?? 0;
      time = examTime ?? 0;
    }

    this.selectedExamName = name;

    this.dashboardService.getLeaderboard(examCode).subscribe(lb => {
      console.log(lb)
      this.selectedLeaderboard = lb.map(x => ({
        ...x,
        name: x.studentName,
        time: x.timeTaken
      }));

      let lbForChart = this.selectedLeaderboard.slice(0, 3);
      if (this.studentInfo && !lbForChart.find(x => x.name === this.studentInfo.name)) {
        lbForChart.unshift({ name: 'You', score: score, time: time, rank: 0 });
        lbForChart = lbForChart.slice(0, 3);
      }
      const names = lbForChart.map(x => x.name === this.studentInfo.name ? 'You' : x.name);
      const times = lbForChart.map(x => +(x.time / 60).toFixed(1));

      this.leaderboardTimeChart = {
        series: [{ name: 'Time (min)', data: times }],
        chart: { type: 'bar', height: 160, toolbar: { show: false } },
        xaxis: { categories: names },
        colors: ['#3B82F6', '#10B981', '#F59E0B'],
        plotOptions: { bar: { borderRadius: 6, horizontal: false, columnWidth: '35%' } },
        dataLabels: { enabled: true },
        tooltip: { y: { formatter: (val: any) => `${val} min` } }
      };
    }, err => {
      this.selectedLeaderboard = [];
      this.leaderboardTimeChart = null;
    });
  }

  formatSeconds(sec: number): string {
    if (!sec && sec !== 0) return '--';
    const min = Math.floor(sec / 60);
    const s = sec % 60;
    return `${min}m ${s.toString().padStart(2, '0')}s`;
  }

  private getAvgTime(): string {
    const exams = this.dashboardData?.attemptedExams || [];
    if (!exams.length) return '--';
    const totalSec = exams.reduce((acc, ex) => acc + ex.timeTaken, 0);
    const avgSec = totalSec / exams.length;
    const min = Math.floor(avgSec / 60);
    return `${min}m`;
  }

  private getMostRecentExam() {
    const exams = this.dashboardData?.attemptedExams || [];
    if (!exams.length) return null;
    return exams.reduce((latest, curr) => {
      return new Date(curr.date) > new Date(latest.date) ? curr : latest;
    });
  }
}
