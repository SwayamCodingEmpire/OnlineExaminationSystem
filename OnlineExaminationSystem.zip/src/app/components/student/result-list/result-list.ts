export interface ResultList {
  testName: string;
  totalMarks: number;
  marksSecured: number;
  average: number;
}
